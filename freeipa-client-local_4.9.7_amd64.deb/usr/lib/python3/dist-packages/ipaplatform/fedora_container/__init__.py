#
# Copyright (C) 2020  FreeIPA Contributors see COPYING for license
#
"""
This module contains Fedora Container specific platform files.
"""
NAME = "fedora_container"
