#
# Copyright (C) 2020 FreeIPA Contributors, see COPYING for license
#

"""
This module contains SUSE specific platform files.
"""
