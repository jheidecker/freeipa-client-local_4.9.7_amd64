#
# Copyright (C) 2020  FreeIPA Contributors see COPYING for license
#
"""
This module contains RHEL Container specific platform files.
"""
NAME = "rhel_container"
